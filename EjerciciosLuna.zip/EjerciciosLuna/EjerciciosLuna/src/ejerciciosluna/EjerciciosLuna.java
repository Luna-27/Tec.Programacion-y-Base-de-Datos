/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciosluna;

import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class EjerciciosLuna {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Por favor, ingrese 2 números enteros.");
        System.out.println("Ingrese el primero y presione enter: ");
        int num1 = teclado.nextInt ();
        System.out.println("Ingrese el segundo y presione enter: ");
        int num2 = teclado.nextInt();
        
        num1 += 17;
        num2 -= 10;
        
        System.out.println("El primer número aumentado en 17 es: " + num1);
        System.out.println("El segundo número decrementado en 10 es: " + num2);
        
        //-----------------
        
        System.out.println("Por favor ingrese la altura y la base de un rectángulo.");
        System.out.println("Ingrese la atura y presione enter: ");
        double altura = teclado.nextDouble();
        System.out.println("Ingrese la base y presione enter: ");
        double base = teclado.nextDouble();
        
        double area = base * altura;
        double perimetro = (base * 2) + (altura * 2);
        //double perimetro = (base + altura) * 2;
        
        System.out.println("El área del rectágulo es: " + area);
        System.out.println("El perímetro del rectángulo es: " + perimetro);
        
        //--------------
        
        System.out.println("Por favor ingrese el radio de un círculo y presione enter: ");
        double radio = teclado.nextDouble();
        
        //final double pi = 3.14;
        // double area2 = pi * (radio * radio);
        double area2 = 3.14 * (radio * radio);
        System.out.println("El área del cículo es: " + area2);
        
        //------------
        
        

    }
    
}
