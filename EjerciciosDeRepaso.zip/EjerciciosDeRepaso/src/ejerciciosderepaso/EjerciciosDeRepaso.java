/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciosderepaso;

import java.util.Scanner;

/**
 *
 * @author yokol
 */
public class EjerciciosDeRepaso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         Scanner teclado = new Scanner(System.in);
        System.out.println("Por favor ingrese 2 números.");
        System.out.println("Ingrese el primer número y presione enter: ");
        int num1 = teclado.nextInt();
        System.out.println("Ingrese el segundo número y presione enter: ");
        int num2 = teclado.nextInt();
       
        
        int aumentado = num1 + 17;
        int decrementado = num2 - 10;
        
        System.out.println("El primer número aumentado en 17 es: " + aumentado);
        System.out.println("El segundo número decrementado en 10 es: " + decrementado);
        
        
        System.out.println("Por favor ingrese la base y la altura de un rectángulo.");
        System.out.println("Ingrese la base y presiones enter: ");
        int base = teclado.nextInt();
        System.out.println("Ingrese la altura y presione enter: ");
        int altura = teclado.nextInt();
        
        int area = base * altura;
        int perimetro = (base * 2) + (altura * 2);
        
        System.out.println("El área del rectángulo es: " + area);
        System.out.println("El périmetro del rectángulo es: " + perimetro);
                
        
        
    }
    
}
