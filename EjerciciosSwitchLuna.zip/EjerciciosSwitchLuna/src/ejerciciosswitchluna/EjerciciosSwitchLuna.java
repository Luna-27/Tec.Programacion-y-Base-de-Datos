/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciosswitchluna;

import java.util.Scanner;

/**
 *
 * @author yokol
 */
public class EjerciciosSwitchLuna {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
Crear un programa que simule la petición de
una opción según el siguiente menú y muestre
en pantalla que ha ingresado a la opción
seleccionada con las opciones siguientes:
        
¡Gracias por contactarte con nosotros!
¿En qué podemos ayudarte?
A) Documentación
B) Cotización
C) Asistencia
D) Siniestros
E) Información de Pagos
F) Otras Consultas
G) Anulación
Escribe la letra de la opción seleccionada.
        
Debe mostrarse:
Has elegido Documentación (o la opción que haya elegido)
*/
        System.out.println("¡Gracias por contactarte con nosotros!");
        System.out.println("¿En qué podemos ayudarte?");
        System.out.println("""
                           A) Documentaci\u00f3n
                           B) Cotizaci\u00f3n
                           C) Asistencia
                           D) Siniestros
                           E) Informaci\u00f3n de Pagos
                           F) Otras Consultas
                           G) Anulaci\u00f3n
                           Escribe la letra de la opci\u00f3n seleccionada.""");
        
        String letra = "C";
        switch(letra){
            case "A": System.out.println("Has elegido Documentación");break;
            case "B": System.out.println("Has elegido Cotización");break;
            case "C": System.out.println("Has elegido Asistencia");break;
            case "D": System.out.println("Has elegido Siniestros");break;
            case "E": System.out.println("Has elegido Información de Pagos");break;
            case "F": System.out.println("Has elegido Otras Consultas");break;
            case "G": System.out.println("Has elegido Anulación");break;
        }
/*
Solicitar al usuario que ingrese dos números.
Luego ofrecerle un menú con las siguientes opciones:
1-suma 2-resta 3-multiplicación 4-división
Finalmente, mostrar el resultado de la operación
aritmética elegida.
*/
        int num1;
        int num2;
        int num3;
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Por favor, ingrese dos números enteros.");
        System.out.println("Ingrese el primero.");
        num1 = teclado.nextInt();
        System.out.println("Ingrese el segundo.");
        num2 = teclado.nextInt();
        
        System.out.println("""
                           Elija una de las siguientes opciones:
                           1-suma
                           2-resta
                           3-multiplicaci\u00f3n
                           4-divisi\u00f3n""");
        num3 = teclado.nextInt();
        
        switch(num3){
            case 1: System.out.println("La suma de sus dos números es: " + (num1 + num2));break;
            case 2: System.out.println("La resta de sus dos números es: " + (num1 - num2));break;
            case 3: System.out.println("La multiplicación es: " + (num1 * num2));break;
            case 4: System.out.println("La división es: " + (num1 / num2));
        }
      
        
        
        
        
    }
    
}
