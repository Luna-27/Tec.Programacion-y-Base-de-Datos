/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author alumno
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //string es una clase
        String nombre= "Marcela";
        System.out.println(nombre);
        
        //pasar texto a mayusculas
        System.out.println(nombre.toUpperCase());
        System.out.println(nombre);
        nombre=nombre.toUpperCase(); //para pasarlo a mayuscula definitivamente
        System.out.println(nombre);
        
        //pasar texto a minusculas
        System.out.println(nombre.toLowerCase());
        System.out.println(nombre);
        nombre=nombre.toLowerCase(); //para pasarlo a minuscula definitivamente
        System.out.println(nombre);
        
        
        String palabra1="cuesta";
        String palabra2="subir";
        String palabra3="la";
        String palabra4="a";
        String palabra5="e";
        String palabra6="l";
        String palabra7="v";
        String palabra8="s";
        String palabra9="n";
        String palabra10="d";
        String palabra11="y";
        String palabra12="medio";
        String palabra13=",";
       
        
       
        System.out.println(palabra4.toUpperCase()+" "+palabra1+" "+palabra6+palabra5+" "+palabra1+" "+palabra2+" "+palabra3+" "+palabra1+" "+palabra11+" "+palabra5+palabra9+" "+palabra12+" "+palabra10+palabra5+" "+palabra3+" "+palabra1+palabra13+" "+palabra7+palabra4+" "+palabra11+" "+palabra8+palabra5+" "+palabra4+palabra1);
        
        
    }
    
}
